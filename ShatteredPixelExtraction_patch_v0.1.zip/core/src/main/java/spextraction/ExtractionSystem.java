
package spextraction;
public class ExtractionSystem {
    public static void maybeSpawnPortal(Object level) {
        // TODO integrate with SPD Level API:
        // if (current floor >= minFloorForPortal && roll(chancePerFloorPercent)) place portal actor
    }
    public static void enableBossExtract(Object level) {
        // spawn guaranteed portal on boss floor (after chest)
    }
    public static void onHardcoreDeath() {
        // purge inventory + equipment, leave stash intact
    }
    public static boolean roll(int pct) { return ExtractionConfig.rng.nextInt(100) < pct; }
}
