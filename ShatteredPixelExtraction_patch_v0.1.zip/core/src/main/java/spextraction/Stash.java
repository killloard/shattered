
package spextraction;
import java.util.ArrayList; import java.util.List;
public class Stash {
    private static final int MAX_SLOTS = 50;
    private static final List<Object> items = new ArrayList<>(); // Replace Object with SPD Item type
    public static int maxSlots(){ return MAX_SLOTS; }
    public static List<Object> all(){ return items; }
    public static boolean deposit(Object item){ if(items.size()>=MAX_SLOTS) return false; items.add(item); return true; }
    public static boolean withdraw(Object item){ return items.remove(item); }
    public static void clear(){ items.clear(); }
}
