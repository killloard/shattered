
package spextraction.loot;
import spextraction.ExtractionConfig; import spextraction.Difficulty; import java.util.Random;
public class RarityRoller {
    public static Rarity rollForWeaponArmor(){
        Random r = ExtractionConfig.rng; Difficulty d = ExtractionConfig.current; int n = r.nextInt(10000);
        if (d == Difficulty.NORMAL){
            if (n < 8000) return Rarity.COMMON;
            if (n < 9500) return Rarity.UNCOMMON;
            if (n < 9900) return Rarity.RARE;
            if (n < 9990) return Rarity.EPIC;
            return Rarity.LEGENDARY;
        } else if (d == Difficulty.MASTER){
            if (n < 5500) return Rarity.COMMON;
            if (n < 8500) return Rarity.UNCOMMON;
            if (n < 9700) return Rarity.RARE;
            if (n < 9950) return Rarity.EPIC;
            return Rarity.LEGENDARY;
        } else {
            if (n < 3000) return Rarity.COMMON;
            if (n < 6500) return Rarity.UNCOMMON;
            if (n < 9200) return Rarity.RARE;
            if (n < 9900) return Rarity.EPIC;
            return Rarity.LEGENDARY;
        }
    }
    public static boolean allowRingDrop(){
        switch(ExtractionConfig.current){
            case NORMAL: return ExtractionConfig.rng.nextInt(100) < 2;
            case MASTER: return ExtractionConfig.rng.nextInt(100) < 5;
            case NIGHTMARE: return ExtractionConfig.rng.nextInt(100) < 8;
        } return false;
    }
    public static boolean allowArtifactDrop(){
        switch(ExtractionConfig.current){
            case NORMAL: return ExtractionConfig.rng.nextInt(1000) < 5;
            case MASTER: return ExtractionConfig.rng.nextInt(1000) < 10;
            case NIGHTMARE: return ExtractionConfig.rng.nextInt(1000) < 20;
        } return false;
    }
}
