
package spextraction.loot;
public class ItemHooks {
    public static Object applyRarityRolls(Object item){
        // If item is Weapon/Armor, attach Rarity metadata (extend SPD classes or use tags).
        return item;
    }
}
