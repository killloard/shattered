
package spextraction.loot;
public enum Rarity { COMMON, UNCOMMON, RARE, EPIC, LEGENDARY; }
