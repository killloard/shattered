
package spextraction;
public enum Difficulty {
    NORMAL, MASTER, NIGHTMARE;
    public String displayName() {
        switch (this) {
            case NORMAL: return "Normal";
            case MASTER: return "Master";
            case NIGHTMARE: return "Nightmare";
        }
        return name();
    }
}
