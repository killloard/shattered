
package spextraction.ui;
import spextraction.Difficulty; import spextraction.ExtractionConfig;
public class DifficultySelectScreen {
    public static void push(Runnable onChosen){
        // Render 3 buttons (Grey=Normal, Purple=Master, Blood Red=Nightmare) with tooltips.
        // Example flow:
        // ExtractionConfig.setDifficulty(Difficulty.MASTER);
        // onChosen.run();
    }
}
