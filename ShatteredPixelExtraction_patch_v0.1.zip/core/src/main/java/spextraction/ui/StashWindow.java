
package spextraction.ui;
import spextraction.Stash;
public class StashWindow {
    public static void show(){
        // Draw 10x5 grid for stash items; enable transfers with the hero's inventory.
    }
}
