
package spextraction.ui;
public class ExtractPopup {
    public static void show(Runnable onYes, Runnable onNo){
        // Popup: "Escape Portal — Do you wish to extract?"
        // [YES] -> onYes.run();  [NO] -> onNo.run();
    }
}
