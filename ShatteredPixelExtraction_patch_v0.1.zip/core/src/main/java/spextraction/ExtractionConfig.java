
package spextraction;
import java.util.Random;

public class ExtractionConfig {
    public static Difficulty current = Difficulty.NORMAL;
    public static final Random rng = new Random();
    public static final int COLOR_NORMAL = 0x888888;   // Grey
    public static final int COLOR_MASTER = 0x7A3BA7;   // Purple
    public static final int COLOR_NIGHTMARE = 0xB0121B; // Blood Red
    public static int minFloorForPortal = 2;
    public static int chancePerFloorPercent = 70;

    public static void init() { setDifficulty(Difficulty.NORMAL); }

    public static void setDifficulty(Difficulty d) {
        current = d;
        switch (d) {
            case NORMAL:    minFloorForPortal = 2; chancePerFloorPercent = 70; break;
            case MASTER:    minFloorForPortal = 3; chancePerFloorPercent = 45; break;
            case NIGHTMARE: minFloorForPortal = 4; chancePerFloorPercent = 25; break;
        }
    }
    public static void onDifficultyChosen() { /* recompute tables if needed */ }
}
