
# Shattered Pixel Extraction — v0.1 Patch Bundle
(For Shattered Pixel Dungeon)

This adds Extraction Mode:
- Difficulty select (Normal / Master / Nightmare) **after gearing, before dungeon**
- **Escape Portals** (swirling) with “Extract? Yes/No” popup
- **Boss chest → then Extract-or-Continue**
- **Hardcore death**: lose everything
- **Stash** (50 slots) in Hub
- **Rarity** for Weapons/Armor; Rings/Artifacts much rarer
- Extraction density scales by difficulty

## Install
1) Clone SPD.
2) Copy the contents of this zip into SPD repo **root**.
3) Wire hooks in SPD (core module):
   - Init: `spextraction.ExtractionConfig.init();`
   - Before entering dungeon: `spextraction.ui.DifficultySelectScreen.push(() -> { spextraction.ExtractionConfig.onDifficultyChosen(); /* continue */ });`
   - After level gen: `spextraction.ExtractionSystem.maybeSpawnPortal(level);`
   - After boss chest: `spextraction.ExtractionSystem.enableBossExtract(level);`
   - On death: `spextraction.ExtractionSystem.onHardcoreDeath();`
   - On drops: `item = spextraction.loot.ItemHooks.applyRarityRolls(item);`
   - Hub Stash button: `spextraction.ui.StashWindow.show();`

Build with SPD's Gradle (`desktop:run`, `desktop:dist`).

License: GPL-3.0. Keep PD/SPD credits.
Title screen text: **Shattered Pixel Extraction** — *Survive the Depths — or Lose It All*
